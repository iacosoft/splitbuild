Short:  Split & Build
Author: (http://www.iacosoft.com) (c) 2024, Giovanni Iacobelli 
Uploader: info@iacosoft.com Giovanni Iacobelli 
Type: util/cli 
Architecture: i386-aros
URL: http://www.iacosoft.com/home/aros.asp#SPLIT
Version: 1.5
Kurz: Split & Build


Split & Build v1.5



INTRODUCTION
In 1997 I wrote this little program to split large files
size into small files for transporting them to floppy disks. Definitely not today
there is no longer this need but nevertheless I decided to compile it anyway
AROS. The source is written in ANSI C and I have not changed almost anything..
There is already a similar program on Linux/Aros... mine works differently.
You don't have to specify the size but the names of the files you want to generate :)

USE

see the Split.txt file (original x MS-DOS)


DISTRIBUTION
The software is FREEWARE.
So it can be freely distributed for free.
It may be freely distributed on the net or in collections of P.D. 
and Shareware on CD-Rom.
Please distribute the program together with all other files included 
in the package.


NO WARRANTY ...
The author assumes no responsibility for the damage that the program 
or its use could cause:
EACH ONE USES THIS SOFTWARE AT YOUR OWN RISK !!!
Furthermore, the author does not guarantee the perfect functioning of
the program.


CONTACTS
Anyone who wants to get in touch with the author can do so at the 
email address mentioned at the head of this documentation.
We welcome reports of program anomalies or malfunctions, comments, 
suggestions, etc.
Please specify the OS version.



########
ITALIANO
########

INTRODUZIONE
Nel lontano 1997 scrissi questo programmino per dividere file di grandi
dimensioni in piccoli file per trasportarli su floppy. Oggi sicuramente non 
c'� pi� questa esigenza ma tuttavia ho deciso lo stesso di compilarlo su 
AROS. Il sorgente � scritto in ANSI C e non ho modificato quasi nulla..
Su linux/aros � gi� presente un programma analogo.. il mio lavora in modo differente.
Non devi specificare la dimensione ma i nomi dei file che vuoi generare :)

 
USO
vedere il file Split.txt (originale x MS-DOS)



DISTRIBUZIONE
Il programma rientra nella categoria dei programmi FREEWARE. 
Quindi potra' essere liberamente distribuito gratuitamente. 
Potra' essere liberamente distribuito in rete o in raccolte di programmi
di P.D. e Shareware su CD-Rom. 
Si prega di distribuire il programma assieme a tutti gli altri files 
inclusi nel pacchetto. 



NESSUNA GARANZIA...
L'autore non si assume nessuna responsabilita' sui danni che il programma
o il suo uso potrebbe causare: 
OGNIUNO USI QUESTO SOFTWARE A SUO RISCHIO E PERICOLO!!! 
Inoltre l'autore non garantisce il perfetto funzionamento del programma. 


CONTATTI
Chiunque voglia mettersi in contatto con l'autore lo puo' fare all'indirizzo
email citato a capo di questa documentazione. 
Sono gradite segnalazioni di anomalie del programma o di cattivo 
funzionamento, commenti, suggerimenti, ecc.. 
Si prega di specificare la versione del Sistema Operativo. 